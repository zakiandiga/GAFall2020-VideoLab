#include <sys/types.h>
#include <android/asset_manager_jni.h>
#include <android/asset_manager.h>
#include <jni.h>

JavaVM* java_vm = NULL;
extern CAkFilePackageLowLevelIOBlocking g_lowLevelIO;

AKRESULT InitAndroidIO(jobject& out_jActivity)
{	
	if (java_vm == NULL)
		return AK_Fail;

	JNIEnv* lJNIEnv;
	java_vm->GetEnv((void**)&lJNIEnv, JNI_VERSION_1_6);

	jclass classActivity = lJNIEnv->FindClass("com/unity3d/player/UnityPlayer");
	jfieldID fieldActivity = lJNIEnv->GetStaticFieldID(classActivity, "currentActivity", "Landroid/app/Activity;");
	out_jActivity = lJNIEnv->GetStaticObjectField(classActivity, fieldActivity);
	
	g_lowLevelIO.InitAndroidIO(java_vm, out_jActivity);
	return AK_Success;
}

jint JNI_OnLoad(JavaVM* vm, void* reserved)
{
	java_vm = vm;
	return JNI_VERSION_1_6;		// minimum JNI version
}
